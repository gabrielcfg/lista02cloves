import csv

# Função para exibir os filmes disponíveis
def exibir_filmes():
    print("Filmes Disponíveis:")
    for i, filme in enumerate(filmes, start=1):
        print(f"{i}. {filme['titulo']} - {filme['horario']}")

# Função para realizar uma reserva
def fazer_reserva(filme_index, quantidade):
    if 1 <= filme_index <= len(filmes):
        filme = filmes[filme_index - 1]
        reserva = {
            'filme': filme['titulo'],
            'horario': filme['horario'],
            'quantidade': quantidade,
            'total': quantidade * filme['preco']
        }
        reservas.append(reserva)
        print("Reserva realizada com sucesso!")
    else:
        print("Filme não encontrado.")

# Função para exibir reservas
def exibir_reservas():
    total = 0
    print("Reservas:")
    for reserva in reservas:
        print(f"Filme: {reserva['filme']}, Horário: {reserva['horario']}, Quantidade: {reserva['quantidade']}, Total: R${reserva['total']:.2f}")
        total += reserva['total']
    print(f"Total a pagar: R${total:.2f}")

# Função para salvar as reservas em um arquivo de texto
def salvar_reservas():
    with open("C:/Users/Gabriel/Desktop/LISTA2/#09/movies.csv", "w") as arquivo:
        for reserva in reservas:
            arquivo.write(f"Filme: {reserva['filme']}, Horário: {reserva['horario']}, Quantidade: {reserva['quantidade']}, Total: R${reserva['total']:.2f}\n")

# Inicialização dos filmes disponíveis
filmes = [
    {'titulo': 'Carros 3', 'horario': '10:00', 'preco': 10.0},
    {'titulo': 'Velozes e furiosos 28', 'horario': '14:30', 'preco': 12.0},
    {'titulo': 'jigsaw', 'horario': '18:15', 'preco': 11.5}
]

# Lista de reservas
reservas = []

# Loop principal
while True:
    print("\nBem vindo ao CineGab")
    print("1. Exibir Filmes")
    print("2. Fazer Reserva")
    print("3. Exibir Reservas")
    print("4. Sair")
    escolha = input("Escolha uma opção: ")

    if escolha == '1':
        exibir_filmes()
    elif escolha == '2':
        exibir_filmes()
        filme_index = int(input("Escolha o filme (número): "))
        quantidade = int(input("Quantidade de ingressos: "))
        fazer_reserva(filme_index, quantidade)
    elif escolha == '3':
        exibir_reservas()
    elif escolha == '4':
        salvar_reservas()
        print("Obrigado por escolher a CineGab.")
        break
    else:
        print("Opção inválida. Tente novamente.")