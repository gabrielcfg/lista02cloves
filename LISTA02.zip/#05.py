# Dicionário de taxas de câmbio fixas
taxas_de_cambio = {
    "USD": 1.0,
    "EUR": 0.85,
    "GBP": 0.73
}

# Função para converter moedas
def converter_moeda(valor, moeda_de, moeda_para):
    if moeda_de in taxas_de_cambio and moeda_para in taxas_de_cambio:
        taxa_de_cambio_de = taxas_de_cambio[moeda_de]
        taxa_de_cambio_para = taxas_de_cambio[moeda_para]
        valor_convertido = valor * (taxa_de_cambio_para / taxa_de_cambio_de)
        return valor_convertido
    else:
        return "Moeda não suportada."

# Função principal
def main():
    print("Conversor de Moedas")
    print("Moedas suportadas: USD, EUR, GBP")
    
    moeda_de = input("Digite a moeda de origem: ").upper()
    moeda_para = input("Digite a moeda de destino: ").upper()
    
    if moeda_de == moeda_para:
        print("As moedas de origem e destino são as mesmas. Nenhuma conversão necessária.")
        return
    
    valor = float(input("Digite o valor a ser convertido: "))
    
    resultado = converter_moeda(valor, moeda_de, moeda_para)
    
    if type(resultado) == str:
        print(resultado)
    else:
        print(f"{valor} {moeda_de} equivalem a {resultado} {moeda_para}")

main()
