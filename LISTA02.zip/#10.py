import requests

print("Mapa do Tempo")

cidade = input("\nQual cidade você deseja pesquisar?")

api_key = "03ad37f304ca30f1f403731a8718ffe6" 
link = f"https://api.openweathermap.org/data/2.5/weather?q={cidade}&appid={api_key}&lang=pt_br"

requisicao = requests.get(link)
requisicao_d = requisicao.json()
descricao = requisicao_d["weather"][0]["description"]
temperatura_a = requisicao_d["main"]["temp"] - 273.15
temperatura_m = requisicao_d["main"]["temp_min"] - 273.15
temperatura_M = requisicao_d["main"]["temp_max"] - 273.15

print(f"\nO clima está: {descricao}\nTemperatura Atual:  {temperatura_a:.0f}°C\nCom Temperatura Mínima de: {temperatura_m:.0f}°C\nE Temperatura Máxima de: {temperatura_M:.0f}°C\n")
