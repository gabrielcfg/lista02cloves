print("Calculadora de IMC\n")
peso = float(input("\ninserir o peso: "))
altura = float(input("\ninserir a altura em metros: "))
imc = peso / (altura**2)
print(f"\nO IMC é de: {imc:.2f}\n")

if imc < 18.5:
    print("Você está abaixo do peso ideal.")
elif 18.5 <= imc < 24.9:
    print("Seu peso está ideal.")
elif 24.9 <= imc < 29.9:
    print("Você está com sobrepeso.")
else:
    print("Você está obeso.")
