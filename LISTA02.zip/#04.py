import time
print("\n Bem Vindo ")
print("\nObrigado por escolher o banco CRICCIO")
valor = 3500

def menu(valor):
   menu_v = int(input("\nQual opção desejada? \n1 - Sacar\n2 - Depositar\n3 - Saldo\n0 - Sair\n\nOpção: "))
   print("========================================")
   if menu_v == 1:
     print("O Sr(a) escolheu a opção de Saque")
     
     saque = float(input("Qual valor o Sr.(a) deseja sacar? "))
     valor -= saque
     
     print(f"Novo saldo: R${valor}")
     menu(valor)

   elif menu_v == 2:
      print("O Sr(a) escolheu a opçao de Deposito")
      deposito = float(input("\nQual valor o Sr.(a) depositar? "))
      valor += deposito
      print(f"Novo saldo: R${valor}")
      menu(valor)

   elif menu_v == 3:
      print(f"O Sr(a) escolheu a opção Saldo\nO valor atual na sua conta é de: R${valor}")
      
      menu(valor)
      
   elif menu_v == 0:
      print(f"\n Obrigado por escolher o banco Criccio\n\nO seu saldo final foi: R${valor}\n")
   
   else:
      print("\nO Sr(a) inseriu um valor incorreto. Por favor, insira um valor válido.")
     
      menu(valor)
      
menu(valor)