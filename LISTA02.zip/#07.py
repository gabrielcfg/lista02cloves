import random

print("Adivinhe o número\n")

valor_A = random.randint(0,50)

while True:
  print("================================================")
  valor_U = float(input("\nDigite o valor que quer chutar\nValor: "))
  if valor_A == valor_U:
    print("\n Você acertou")
    break
  elif valor_A <= valor_U:
    print(f"\nEsse numero: {valor_U} é maior")
  else:
    print(f"\nEsse numero: {valor_U} é menor")